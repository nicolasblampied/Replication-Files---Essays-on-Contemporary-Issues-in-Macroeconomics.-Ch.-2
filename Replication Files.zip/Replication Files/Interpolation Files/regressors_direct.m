function [X,b_start]=regressors1(Xreg, Y_ext, X_tr)
%'regressors' constructs array struct X in which all exogenous regressors
%are stored as matrices (including constant). 
%Structure of X is: X(#of regressor).#ofindicator


global Y_m; global Y_q; global X_m;
b_start=NaN(20,size(Y_ext,2));


%First indicator: Real GDP

X(1).first=[ones(size(Xreg,1),1), Xreg(:,1)];
X(2).first=[ones(size(Xreg,1),1), Xreg(:,2)];

    %Starting values
    bx_start1=[0 1]';       %bx_start1 = 0|1; 
    rho_start1=0.2;         %rho_start1 = 0.2;
    seps_start1=0.3;
    
    bx_start2=[0 1]';
    rho_start2=0.2;
    seps_start2=0.3;
    
    %b_start=[];
    %b_start=[b_start, [bx_start1; rho_start1; seps_start1; bx_start2; rho_start2; seps_start2]];
    b_start1=[bx_start1; rho_start1; seps_start1; bx_start2; rho_start2; seps_start2];
    b_start(1:size(b_start1,1),1)=b_start1;
    
%     for i=1:2
%     bx_start=ones(size(X(i).second,2),1);
%     bx_start(1)=0;
%     rho_start=0.2;
%     bx_start=[bx_start; rho_start]
%     end
% 
%     tmp2 = (NR_STRUC_Q-pr_res2); 
%     tmp = tmp2(~any(isnan(tmp2),2),:); %delete rows with missing values
%     seps_start2 = std(tmp)/mean(smt); 
    

%Second Indicator: GDP Deflator
    
    X(1).second=[ones(size(Xreg,1),1), Xreg(:,3)];
    X(2).second=[ones(size(Xreg,1),1), Xreg(:,4)];

    
    %Starting values
    bx_start1=[0 1]';       %bx_start1 = 0|1; 
    rho_start1=0.2;         %rho_start1 = 0.2;
    seps_start1=0.3;
    
    bx_start2=[0 1]';       %bx_start1 = 0|1; 
    rho_start2=0.2;         %rho_start1 = 0.2;
    seps_start2=0.3;
    
     
    b_start1=[bx_start1; rho_start1; seps_start1; bx_start2; rho_start2; seps_start2];
    b_start(1:size(b_start1,1),2)=b_start1;
    
    %b_start=[b_start, [bx_start1; rho_start1; seps_start1; bx_start2; rho_start2; seps_start2; bx_start3; rho_start3; seps_start3]];
   
  

     
    
end