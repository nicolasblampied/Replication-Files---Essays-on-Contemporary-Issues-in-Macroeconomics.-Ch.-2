%%% These files allow to estimate the smooth local projections (SLP) in the terms Barnichon and Brownlees (2019) to the MP Shock
%%% of Jarocinski and Karadi (2020)

%%% Acknowledgements: These codes were retrieved from the supplementary
%%% material of Barnichon and Brownlees (2019) and adapted for the needs of the present paper. 

clc
clear 

%Select dataset in levels or diff for the corresponding data span

%load 'Business Asymmetry - DIFF - 1990-2016.mat'
%load 'Business Asymmetry - LEVEL - 1990-2007.mat'
load 'Business Asymmetry - LEVEL - 1990-2016.mat'

%Select data size (T=323 for full sample and T=215 for subsample)

T = 323;
P  = 0; % number of lags used in LP for controls

%Define variables (in level or first differences)


%%%%%%%Data in log-level

%Real GDP

%GDPG=(log(RGDP(:,1)))*100; 

%Markup estimates

Mu_CD=(log(Mu_cd(:,1)))*100;
Mu_CES_KVU=Mu_ces_oh_yk_ums(:,1)*100;
Mu_CES_KVU_OH=Mu_ces_yk_ums(:,1)*100;
IP=(log(IndProd(:,1)))*100;

%%%%%%%Data in diff-log

%Real GDP

%GDPG=diff(log(RGDP(:,1)))*100;

%Markup estimates

%Mu_CD=diff(log(Mu_cd(:,1)))*100; 
%Mu_CES_KVU=diff(Mu_ces_yk_ums(:,1))*100; 
%Mu_CES_KVU_OH=diff(Mu_ces_oh_yk_ums(:,1))*100; 
%IP=diff(log(IndProd(:,1)))*100;

%% Estimating the IRFs of the dependent variables to the MP Shock

H_min = 1; 
H_max = 36; 

subplot(2,1,2)
autocorr(MSExp) %Autocorrelation function of the shock chosen
set(gca,'FontSize',16)

%Select the variable for which to calculate the IRF
    
y = [Mu_CD];
    
%Select lags of the dependent variable
    
y_Lags=lagmatrix(y,1:6);
    
    
% Select the Shock (MSPos, MSExp or MSRec) 
    
x = [MSExp];
    
%Create Controls and choose number of lags

USRate_1=lagmatrix(USRate,1:6); %Lags of the FED Funds rate)
MSPos_Lags=lagmatrix(MSPos,1:7); %Lags of the MSPos Shock)
MSRec_Lags=lagmatrix(MSRec,1:7); %Lags of the MPSRec Shock)
MSExp_Lags=lagmatrix(MSExp,1:7); %Lags of the MSExp Shock)
    

% Choose and include controls in w
    
w = [MSExp_Lags IShock USRate_1 y_Lags TT D_2008]; 
    
newData = cat(2, y, x, w);

newData(any(isnan(newData), 2), :) = [];

% Re-declare variables after removing missings
y  = newData(:,1); % endogenous variable
x  = newData(:,2); % endogenous variable related to the shock
w  = newData(:,3:size(newData,2)); % control variables and lags

lp = locproj(y,x,w,H_min,H_max,'reg'); % IRFs from standard Local Projection

r = 2; %(r-1)=order of the limit polynomial (so r=2 implies the IR is shrunk towards a line )
lambda = 100; % value of penalty

slp    = locproj(y,x,w,H_min,H_max,'smooth',r,lambda); %IRFs from Smooth Local Projection
slp_lim= locproj(y,x,w,H_min,H_max,'smooth',r,1e10); % Limit IRFs in Smooth Local Projection

figure(1)
hold on,
plot( 0:H_max , [ lp.IR slp.IR slp_lim.IR] )
plot( 0:H_max , zeros(H_max+1,1) , '-k' , 'LineWidth' , 2 )
grid
xlim([0 H_max])
legend('IR_{lp}','IR_{slp}','IR_{slp,max pen}','Location','Best')

%% Cross-Validation Choice of Lambda

slp = locproj(y,x,w,H_min,H_max,'smooth',r,0.01);

lambda = [ 1:0.5:10] * T;
slp    = locproj_cv(slp,5,lambda);

figure(2)
plot( lambda , slp.rss , '-o' )

lambda_opt = lambda( min( slp.rss ) == slp.rss );

%% Confidence Intervals

lp = locproj(y,x,w,H_min,H_max,'reg'); % IRFs from regular Local Projection
lp = locproj_conf(lp,H_max); 


r      = 2;
slp    = locproj(y,x,w,H_min,H_max,'smooth',r,lambda_opt); 
slp    = locproj_conf(slp,H_max,lambda_opt/2);

figure(3)
hold on,
plot( 0:H_max , slp.IR   , 'r' , 'LineWidth' , 2 )
plot( 0:H_max , slp.conf , 'r' )
plot( 0:H_max , zeros(H_max+1,1) , '-k' , 'LineWidth' , 2 )
grid
xlim([0 H_max])
    